module AuthenticationError
	class Unauthorized < StandardError; end
end