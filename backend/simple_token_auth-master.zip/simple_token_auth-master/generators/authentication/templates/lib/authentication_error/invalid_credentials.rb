module AuthenticationError
	class InvalidCredentials < StandardError; end
end