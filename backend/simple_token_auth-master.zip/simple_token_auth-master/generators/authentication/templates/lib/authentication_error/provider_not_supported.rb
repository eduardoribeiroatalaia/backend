module AuthenticationError
	class ProviderNotSupported < StandardError; end
end